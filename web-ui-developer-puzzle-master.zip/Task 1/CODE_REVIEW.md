All the components are loaded at once it can be loaded lazily.
Modules can be designed properly like book and reading
